/*!
 *  @file AMS_OSRAM_AS7343.h

 *  @mainpage AMS OSRAM AS7343 14-Channel Spectral Sensor
 *
 *  @section intro_sec Introduction
 *
 * 	I2C Driver for the Library for the AS7343 14-Channel Spectral Sensor
 *
 * 	This is a library for the Adafruit AS7343 breakout:
 * 	https://www.adafruit.com/product/4698
 *
 * 	Adafruit invests time and resources providing this open source code,
 *  please support Adafruit and open-source hardware by purchasing products from
 * 	Adafruit!
 *
 *  @section dependencies Dependencies
 *  This library depends on the Adafruit BusIO library
 *
 *  @section author Author
 *
 *  Bryan Siepert for Adafruit Industries
 *
 * 	@section license License
 *
 * 	BSD (see license.txt)
 *
 * 	@section  HISTORY
 *
 *     v1.0 - First release
 */

/*
  This library is adapted from an example with the following Copyright and
  Warranty:

  The main idea is to get fimilar with the
  register configuration. This code helps to learn basic settings and procedure
  to read out raw values with different SMUX configuration. Also defined the
  procedure to set the default flicker detection for 100 and 120 Hz.

  Written by Sijo John @ ams AG, Application Support in October, 2018

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

#ifndef _AMS_OSRAM_AS7343_H
#define _AMS_OSRAM_AS7343_H

#include "Adafruit_BusIO_Register.h"

#define AS7343_I2CADDR_DEFAULT 0x39 ///< AS7343 default i2c address
#define AS7343_CHIP_ID 0x81         ///< AS7343 default device id from datasheet

#define AS7343_WHOAMI 0x5A ///< Chip ID register

#define AS7343_ASTATUS 0x60     ///< AS7343_ASTATUS (unused)
#define AS7343_CH0_DATA_L_ 0x61 ///< AS7343_CH0_DATA_L (unused)
#define AS7343_CH0_DATA_H_ 0x62 ///< AS7343_CH0_DATA_H (unused)
#define AS7343_ITIME_L 0x63     ///< AS7343_ITIME_L (unused)
#define AS7343_ITIME_M 0x64     ///< AS7343_ITIME_M (unused)
#define AS7343_ITIME_H 0x65     ///< AS7343_ITIME_H (unused)
#define AS7343_CONFIG 0x70 ///< Enables LED control and sets light sensing mode
#define AS7343_STAT 0x71   ///< AS7343_STAT (unused)
#define AS7343_EDGE 0x72   ///< AS7343_EDGE (unused)
#define AS7343_GPIO 0x73   ///< Connects photo diode to GPIO or INT pins
#define AS7343_LED 0xCD    ///< LED Register; Enables and sets current limit
#define AS7343_ENABLE                                                          \
  0x80 ///< Main enable register. Controls SMUX, Flicker Detection, Spectral
       ///< Measurements and Power
#define AS7343_ATIME 0x81       ///< Sets ADC integration step count
#define AS7343_WTIME 0x83       ///< AS7343_WTIME (unused)
#define AS7343_SP_LOW_TH_L 0x84 ///< Spectral measurement Low Threshold low byte
#define AS7343_SP_LOW_TH_H                                                     \
  0x85 ///< Spectral measurement Low Threshold high byte
#define AS7343_SP_HIGH_TH_L                                                    \
  0x86 ///< Spectral measurement High Threshold low byte
#define AS7343_SP_HIGH_TH_H                                                    \
  0x87                    ///< Spectral measurement High Threshold low byte
#define AS7343_AUXID 0x58 ///< AS7343_AUXID (unused)
#define AS7343_REVID 0x59 ///< AS7343_REVID (unused)
#define AS7343_ID 0x92    ///< AS7343_ID (unused)
#define AS7343_STATUS                                                          \
  0x93 ///< Interrupt status registers. Indicates the occourance of an interrupt
#define AS7343_ASTATUS_ 0x94   ///< AS7343_ASTATUS, same as 0x60 (unused)
#define AS7343_CH0_DATA_L 0x95 ///< ADC Channel Data
#define AS7343_CH0_DATA_H 0x96 ///< ADC Channel Data
#define AS7343_CH1_DATA_L 0x97 ///< ADC Channel Data
#define AS7343_CH1_DATA_H 0x98 ///< ADC Channel Data
#define AS7343_CH2_DATA_L 0x99 ///< ADC Channel Data
#define AS7343_CH2_DATA_H 0x9A ///< ADC Channel Data
#define AS7343_CH3_DATA_L 0x9B ///< ADC Channel Data
#define AS7343_CH3_DATA_H 0x9C ///< ADC Channel Data
#define AS7343_CH4_DATA_L 0x9D ///< ADC Channel Data
#define AS7343_CH4_DATA_H 0x9E ///< ADC Channel Data
#define AS7343_CH5_DATA_L 0x9F ///< ADC Channel Data
#define AS7343_CH5_DATA_H 0xA0 ///< ADC Channel Data
#define AS7343_CH6_DATA_L 0xA1 ///< ADC Channel Data
#define AS7343_CH6_DATA_H 0xA2 ///< ADC Channel Data
#define AS7343_CH7_DATA_L 0xA3 ///< ADC Channel Data
#define AS7343_CH7_DATA_H 0xA4 ///< ADC Channel Data
#define AS7343_CH8_DATA_L 0xA5 ///< ADC Channel Data
#define AS7343_CH8_DATA_H 0xA6 ///< ADC Channel Data
#define AS7343_CH9_DATA_L 0xA7 ///< ADC Channel Data
#define AS7343_CH9_DATA_H 0xA8 ///< ADC Channel Data
#define AS7343_CH10_DATA_L 0xA9 ///< ADC Channel Data
#define AS7343_CH10_DATA_H 0xAA ///< ADC Channel Data
#define AS7343_CH11_DATA_L 0xAB ///< ADC Channel Data
#define AS7343_CH11_DATA_H 0xAC ///< ADC Channel Data
#define AS7343_CH12_DATA_L 0xAD ///< ADC Channel Data
#define AS7343_CH12_DATA_H 0xAE ///< ADC Channel Data
#define AS7343_CH13_DATA_L 0xAF ///< ADC Channel Data
#define AS7343_CH13_DATA_H 0xB0 ///< ADC Channel Data
#define AS7343_CH14_DATA_L 0xB1 ///< ADC Channel Data
#define AS7343_CH14_DATA_H 0xB2 ///< ADC Channel Data
#define AS7343_CH15_DATA_L 0xB3 ///< ADC Channel Data
#define AS7343_CH15_DATA_H 0xB4 ///< ADC Channel Data
#define AS7343_CH16_DATA_L 0xB5 ///< ADC Channel Data
#define AS7343_CH16_DATA_H 0xB6 ///< ADC Channel Data
#define AS7343_CH17_DATA_L 0xB7 ///< ADC Channel Data
#define AS7343_CH17_DATA_H 0xB8 ///< ADC Channel Data

#define AS7343_STATUS2 0x90 ///< Measurement status flags; saturation, validity
#define AS7343_STATUS3                                                         \
  0x91 ///< Spectral interrupt source, high or low threshold
#define AS7343_STATUS5 0xBB ///< AS7343_STATUS5 (unused)
#define AS7343_STATUS4 0xBC ///< AS7343_STATUS6 (unused)
#define AS7343_CFG0                                                            \
  0xBF ///< Sets Low power mode, Register bank, and Trigger lengthening
#define AS7343_CFG1 0xC6 ///< Controls ADC Gain
#define AS7343_CFG3 0xC7 ///< AS7343_CFG3 (unused)
#define AS7343_CFG6 0xF5 ///< Used to configure Smux
#define AS7343_CFG8 0xC9 ///< AS7343_CFG8 (unused)
#define AS7343_CFG9                                                            \
  0xCA ///< Enables flicker detection and smux command completion system
       ///< interrupts
#define AS7343_CFG10 0x65 ///< AS7343_CFG10 (unused)
#define AS7343_CFG12                                                           \
  0x66 ///< Spectral threshold channel for interrupts, persistence and auto-gain
#define AS7343_CFG20 0xD6 //< FIFO and auto SMUX
#define AS7343_PERS                                                            \
  0xCF ///< Number of measurement cycles outside thresholds to trigger an
       ///< interupt
#define AS7343_GPIO2                                                           \
  0x6B ///< GPIO Settings and status: polarity, direction, sets output, reads
       ///< input
#define AS7343_ASTEP_L 0xD4      ///< Integration step size ow byte
#define AS7343_ASTEP_H 0xD5      ///< Integration step size high byte
#define AS7343_AGC_GAIN_MAX 0xD7 ///< AS7343_AGC_GAIN_MAX (unused)
#define AS7343_AZ_CONFIG 0xDE    ///< AS7343_AZ_CONFIG (unused)
#define AS7343_FD_TIME1 0xE0 ///< Flicker detection integration time low byte
#define AS7343_FD_TIME2 0xE2 ///< Flicker detection gain and high nibble
#define AS7343_FD_CFG0 0xDF  ///< AS7343_FD_CFG0 (unused)
#define AS7343_FD_STATUS                                                       \
  0xE3 ///< Flicker detection status; measurement valid, saturation, flicker
       ///< type
#define AS7343_INTENAB 0xF9  ///< Enables individual interrupt types
#define AS7343_CONTROL 0xFA  ///< Auto-zero, fifo clear, clear SAI active
#define AS7343_FIFO_MAP 0xFC ///< AS7343_FIFO_MAP (unused)
#define AS7343_FIFO_LVL 0xFD ///< AS7343_FIFO_LVL (unused)
#define AS7343_FDATA_L 0xFE  ///< AS7343_FDATA_L (unused)
#define AS7343_FDATA_H 0xFF  ///< AS7343_FDATA_H (unused)

#define AS7343_SPECTRAL_INT_HIGH_MSK                                           \
  0b00100000 ///< bitmask to check for a high threshold interrupt
#define AS7343_SPECTRAL_INT_LOW_MSK                                            \
  0b00010000 ///< bitmask to check for a low threshold interrupt


/**
 * @brief Allowable gain multipliers for `setGain`
 *
 */
typedef enum {
  AS7343_GAIN_0_5X,
  AS7343_GAIN_1X,
  AS7343_GAIN_2X,
  AS7343_GAIN_4X,
  AS7343_GAIN_8X,
  AS7343_GAIN_16X,
  AS7343_GAIN_32X,
  AS7343_GAIN_64X,
  AS7343_GAIN_128X,
  AS7343_GAIN_256X,
  AS7343_GAIN_512X,
  AS7343_GAIN_1024X,
  AS7343_GAIN_2048X,
} AS7343_gain_t;

/**
 * @brief Available SMUX configuration commands
 *
 */
typedef enum {
  AS7343_SMUX_CMD_ROM_RESET, ///< ROM code initialization of SMUX
  AS7343_SMUX_CMD_READ,      ///< Read SMUX configuration to RAM from SMUX chain
  AS7343_SMUX_CMD_WRITE, ///< Write SMUX configuration from RAM to SMUX chain
} AS7343_smux_cmd_t;
/**
 * @brief ADC Channel specifiers for configuration
 *
 */
typedef enum {
  AS7343_ADC_CHANNEL_0,
  AS7343_ADC_CHANNEL_1,
  AS7343_ADC_CHANNEL_2,
  AS7343_ADC_CHANNEL_3,
  AS7343_ADC_CHANNEL_4,
  AS7343_ADC_CHANNEL_5,
} AS7343_adc_channel_t;
/**
 * @brief Spectral Channel specifiers for configuration and reading
 *
 */
typedef enum {
  AS7343_CHANNEL_450_FZ,
  AS7343_CHANNEL_555_FY,
  AS7343_CHANNEL_600_FXL,
  AS7343_CHANNEL_855_NIR,
  AS7343_CHANNEL_CLEAR_1,
  AS7343_CHANNEL_FD_1,
  AS7343_CHANNEL_425_F2,
  AS7343_CHANNEL_475_F3,
  AS7343_CHANNEL_515_F4,
  AS7343_CHANNEL_640_F6,
  AS7343_CHANNEL_CLEAR_0,
  AS7343_CHANNEL_FD_0,
  AS7343_CHANNEL_405_F1,
  AS7343_CHANNEL_550_F5,
  AS7343_CHANNEL_690_F7,
  AS7343_CHANNEL_745_F8,
  AS7343_CHANNEL_CLEAR,
  AS7343_CHANNEL_FD,
} AS7343_color_channel_t;

/**
 * @brief The number of measurement cycles with spectral data outside of a
 * threshold required to trigger an interrupt
 *
 */
typedef enum {
  AS7343_INT_COUNT_ALL, ///< 0
  AS7343_INT_COUNT_1,   ///< 1
  AS7343_INT_COUNT_2,   ///< 2
  AS7343_INT_COUNT_3,   ///< 3
  AS7343_INT_COUNT_5,   ///< 4
  AS7343_INT_COUNT_10,  ///< 5
  AS7343_INT_COUNT_15,  ///< 6
  AS7343_INT_COUNT_20,  ///< 7
  AS7343_INT_COUNT_25,  ///< 8
  AS7343_INT_COUNT_30,  ///< 9
  AS7343_INT_COUNT_35,  ///< 10
  AS7343_INT_COUNT_40,  ///< 11
  AS7343_INT_COUNT_45,  ///< 12
  AS7343_INT_COUNT_50,  ///< 13
  AS7343_INT_COUNT_55,  ///< 14
  AS7343_INT_COUNT_60,  ///< 15
} AS7343_int_cycle_count_t;

/**
 * @brief Pin directions to set how the GPIO pin is to be used
 *
 */
typedef enum {
  AS7343_GPIO_OUTPUT, ///< THhe GPIO pin is configured as an open drain output
  AS7343_GPIO_INPUT,  ///< The GPIO Pin is set as a high-impedence input
} AS7343_gpio_dir_t;

/**
 * @brief Wait states for async reading
 */
typedef enum {
  AS7343_WAITING_START, //
  AS7343_WAITING_LOW,   //
  AS7343_WAITING_HIGH,  //
  AS7343_WAITING_DONE,  //
} AS7343_waiting_t;

//class AMS_OSRAM_AS7343;

/*!
 *    @brief  Class that stores state and functions for interacting with
 *            the AS7343 11-Channel Spectral Sensor
 */
struct AMS_OSRAM_AS7343 {
  uint16_t _channel_readings[18];
  AS7343_waiting_t _readingState;

  uint8_t last_spectral_int_source; ///< The value of the last reading of the spectral interrupt source
           ///< register

    //Adafruit_I2CDevice *i2c_dev; ///< Pointer to I2C bus interface
};

void AMS_OSRAM_AS7343_AMS_OSRAM_AS7343(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343_begin(struct AMS_OSRAM_AS7343 *ams, uint8_t i2c_addr, int32_t sensor_id); //uint8_t i2c_addr = AS7343_I2CADDR_DEFAULT, int32_t sensor_id = 0

bool AMS_OSRAM_AS7343_setASTEP(struct AMS_OSRAM_AS7343 *ams, uint16_t astep_value);
bool AMS_OSRAM_AS7343_setATIME(struct AMS_OSRAM_AS7343 *ams, uint8_t atime_value);
bool AMS_OSRAM_AS7343_setGain(struct AMS_OSRAM_AS7343 *ams, AS7343_gain_t gain_value);

uint16_t AMS_OSRAM_AS7343_getASTEP(struct AMS_OSRAM_AS7343 *ams);
uint8_t AMS_OSRAM_AS7343_getATIME(struct AMS_OSRAM_AS7343 *ams);
AS7343_gain_t AMS_OSRAM_AS7343_getGain(struct AMS_OSRAM_AS7343 *ams);

long AMS_OSRAM_AS7343_getTINT(struct AMS_OSRAM_AS7343 *ams);
double AMS_OSRAM_AS7343_toBasicCounts(struct AMS_OSRAM_AS7343 *ams, uint16_t raw);

bool AMS_OSRAM_AS7343_readAllChannels_1(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_readAllChannels_2(struct AMS_OSRAM_AS7343 *ams, uint16_t *readings_buffer);
void AMS_OSRAM_AS7343_delayForData(struct AMS_OSRAM_AS7343 *ams, int waitTime); //int waitTime = 0
uint16_t AMS_OSRAM_AS7343_readChannel(struct AMS_OSRAM_AS7343 *ams, AS7343_adc_channel_t channel);
uint16_t AMS_OSRAM_AS7343_getChannel(struct AMS_OSRAM_AS7343 *ams, AS7343_color_channel_t channel);

bool AMS_OSRAM_AS7343_startReading(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_checkReadingProgress(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_getAllChannels(struct AMS_OSRAM_AS7343 *ams, uint16_t *readings_buffer);

uint16_t AMS_OSRAM_AS7343_detectFlickerHz(struct AMS_OSRAM_AS7343 *ams);

void AMS_OSRAM_AS7343_setup_F1F4_Clear_NIR(struct AMS_OSRAM_AS7343 *ams);
void AMS_OSRAM_AS7343_setup_F5F8_Clear_NIR(struct AMS_OSRAM_AS7343 *ams);

void AMS_OSRAM_AS7343_powerEnable(struct AMS_OSRAM_AS7343 *ams, bool enable_power);
bool AMS_OSRAM_AS7343_enableSpectralMeasurement(struct AMS_OSRAM_AS7343 *ams, bool enable_measurement);

bool AMS_OSRAM_AS7343_setHighThreshold(struct AMS_OSRAM_AS7343 *ams, uint16_t high_threshold);
bool AMS_OSRAM_AS7343_setLowThreshold(struct AMS_OSRAM_AS7343 *ams, uint16_t low_threshold);

uint16_t AMS_OSRAM_AS7343_getHighThreshold(struct AMS_OSRAM_AS7343 *ams);
uint16_t AMS_OSRAM_AS7343_getLowThreshold(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343_enableSpectralInterrupt(struct AMS_OSRAM_AS7343 *ams, bool enable_int);
bool AMS_OSRAM_AS7343_enableSystemInterrupt(struct AMS_OSRAM_AS7343 *ams, bool enable_int);

bool AMS_OSRAM_AS7343_setAPERS(struct AMS_OSRAM_AS7343 *ams, AS7343_int_cycle_count_t cycle_count);
bool AMS_OSRAM_AS7343_setSpectralThresholdChannel(struct AMS_OSRAM_AS7343 *ams, AS7343_adc_channel_t channel);

uint8_t AMS_OSRAM_AS7343_getInterruptStatus(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_clearInterruptStatus(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343_spectralInterruptTriggered(struct AMS_OSRAM_AS7343 *ams);
uint8_t AMS_OSRAM_AS7343_spectralInterruptSource(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_spectralLowTriggered(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_spectralHighTriggered(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343_enableLED(struct AMS_OSRAM_AS7343 *ams, bool enable_led);
bool AMS_OSRAM_AS7343_setLEDCurrent(struct AMS_OSRAM_AS7343 *ams, uint16_t led_current_ma);
uint16_t AMS_OSRAM_AS7343_getLEDCurrent(struct AMS_OSRAM_AS7343 *ams);

void AMS_OSRAM_AS7343_disableAll(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343_getIsDataReady(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_setBank(struct AMS_OSRAM_AS7343 *ams, bool low); // low true gives access to 0x60 to 0x74

AS7343_gpio_dir_t AMS_OSRAM_AS7343_getGPIODirection(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_setGPIODirection(struct AMS_OSRAM_AS7343 *ams, AS7343_gpio_dir_t gpio_direction);
bool AMS_OSRAM_AS7343_getGPIOInverted(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_setGPIOInverted(struct AMS_OSRAM_AS7343 *ams, bool gpio_inverted);
bool AMS_OSRAM_AS7343_getGPIOValue(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_setGPIOValue(struct AMS_OSRAM_AS7343 *ams, bool);

bool AMS_OSRAM_AS7343_digitalSaturation(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_analogSaturation(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_clearDigitalSaturationStatus(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_clearAnalogSaturationStatus(struct AMS_OSRAM_AS7343 *ams);

bool AMS_OSRAM_AS7343__init(struct AMS_OSRAM_AS7343 *ams, int32_t sensor_id); ///TODO

bool AMS_OSRAM_AS7343_enableSMUX(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_enableFlickerDetection(struct AMS_OSRAM_AS7343 *ams, bool enable_fd);
void AMS_OSRAM_AS7343_FDConfig(struct AMS_OSRAM_AS7343 *ams);
int8_t AMS_OSRAM_AS7343_getFlickerDetectStatus(struct AMS_OSRAM_AS7343 *ams);
bool AMS_OSRAM_AS7343_setSMUXCommand(struct AMS_OSRAM_AS7343 *ams, AS7343_smux_cmd_t command);
void AMS_OSRAM_AS7343_writeRegister(struct AMS_OSRAM_AS7343 *ams, uint8_t addr, uint8_t val);
void AMS_OSRAM_AS7343_setSMUXLowChannels(struct AMS_OSRAM_AS7343 *ams, bool f1_f4);

/**
 * @brief Construct a new AMS_OSRAM_AS7343::AMS_OSRAM_AS7343 object
 *
 */
void AMS_OSRAM_AS7343_AMS_OSRAM_AS7343(struct AMS_OSRAM_AS7343 *ams) {
    ams->_readingState = AS7343_WAITING_START;
    ams->last_spectral_int_source = 0;
}

/*!
 *    @brief  Sets up the hardware and initializes I2C
 *    @param  i2c_address
 *            The I2C address to be used.
 *    @param  wire
 *            The Wire object to be used for I2C connections.
 *    @param  sensor_id
 *            The unique ID to differentiate the sensors from others
 *    @return True if initialization was successful, otherwise false.
 */
bool AMS_OSRAM_AS7343_begin(struct AMS_OSRAM_AS7343 *ams, uint8_t i2c_address,
                            int32_t sensor_id) {
  /*
	if () {
    	delete i2c_dev; // remove old interface
  	  }
   */

	//i2c_dev = new Adafruit_I2CDevice(i2c_address);
	//i2c_dev.set_address(i2c_address);
	Adafruit_I2CDevice_set_address(&i2c_dev, i2c_address);

  if (!Adafruit_I2CDevice_begin(&i2c_dev, true)) {
    return false;
  }
  return AMS_OSRAM_AS7343__init(ams, sensor_id);
}

/*!  @brief Initializer for post i2c/spi init
 *   @param sensor_id Optional unique ID for the sensor set
 *   @returns True if chip identified and initialized
 */
bool AMS_OSRAM_AS7343__init(struct AMS_OSRAM_AS7343 *ams, int32_t sensor_id) {

  // silence compiler warning - variable may be used in the future
  (void)sensor_id;

  // make sure we're talking to the right chip
  struct Adafruit_BusIO_Register chip_id_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&chip_id_reg, AS7343_WHOAMI, 1, LSBFIRST, 1);
  //Adafruit_BusIO_Register chip_id_reg = Adafruit_BusIO_Register(AS7343_WHOAMI);
  AMS_OSRAM_AS7343_setBank(ams, true); //Access registers 0x20 to 0x7F
  //uint8_t chip_id = (uint8_t)chip_id_reg.read();
  uint32_t chip_id = (uint32_t)Adafruit_BusIO_Register_read_4(&chip_id_reg);
  AMS_OSRAM_AS7343_setBank(ams, false); //Access to registers 0x80 and above (default)
  if (chip_id != AS7343_CHIP_ID) {
    return false;
  }

  AMS_OSRAM_AS7343_powerEnable(ams, true);

  struct Adafruit_BusIO_Register cfg20_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg20_reg, AS7343_CFG20, 1, LSBFIRST, 1);

  struct Adafruit_BusIO_RegisterBits auto_smux_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&auto_smux_bit, &cfg20_reg, 2, 5);


  if(!Adafruit_BusIO_RegisterBits_write(&auto_smux_bit, 3)) {
    return false;
  }

  return true;
}

/********************* EXAMPLE EXTRACTS **************/
// maybe return a typedef enum
/**
 * @brief Returns the flicker detection status
 *
 * @return int8_t
 */
int8_t AMS_OSRAM_AS7343_getFlickerDetectStatus(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register flicker_val;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&flicker_val, AS7343_FD_STATUS, 1, LSBFIRST, 1);
  return (int8_t)Adafruit_BusIO_Register_read_4(&flicker_val);
}

/**
 * @brief Returns the ADC data for a given channel
 *
 * @param channel The ADC channel to read
 * @return uint16_t The measured data for the currently configured sensor
 */
uint16_t AMS_OSRAM_AS7343_readChannel(struct AMS_OSRAM_AS7343 *ams, AS7343_adc_channel_t channel) {
  (void)ams;
  // each channel has two bytes, so offset by two for each next channel
  struct Adafruit_BusIO_Register channel_data_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&channel_data_reg, (uint16_t)(AS7343_CH0_DATA_L + 2 * channel), 2, LSBFIRST, 1);

  return (uint16_t)Adafruit_BusIO_Register_read_4(&channel_data_reg);
}

/**
 * @brief Returns the reading data for the specified color channel
 *
 *  call `readAllChannels` before reading to update the stored readings
 *
 * @param channel The color sensor channel to read
 * @return uint16_t The measured data for the selected sensor channel
 */
uint16_t AMS_OSRAM_AS7343_getChannel(struct AMS_OSRAM_AS7343 *ams, AS7343_color_channel_t channel) {
  return ams->_channel_readings[channel];
}

/**
 * @brief fills the provided buffer with the current measurements for Spectral
 * channels F1-8, Clear and NIR
 *
 * @param readings_buffer Pointer to a buffer of length 10 or more to fill with
 * sensor data
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_readAllChannels_2(struct AMS_OSRAM_AS7343 *ams, uint16_t *readings_buffer) {

  //enableSMUX();
  //clearAnalogSaturationStatus();
  //clearDigitalSaturationStatus();
    AMS_OSRAM_AS7343_enableSpectralMeasurement(ams, true); // Start integration
    AMS_OSRAM_AS7343_delayForData(ams, 0);                 // I'll wait for you for all time

    struct Adafruit_BusIO_Register channel_data_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&channel_data_reg, AS7343_CH0_DATA_L, 2, LSBFIRST, 1);
  return Adafruit_BusIO_Register_read_1(&channel_data_reg, (uint8_t *)readings_buffer, 36);
}

/**
 * @brief starts the process of getting readings from all channels without using
 * delays
 *
 * @return true: success false: failure (a bit arbitrary)
 */
bool AMS_OSRAM_AS7343_startReading(struct AMS_OSRAM_AS7343 *ams) {
    ams->_readingState = AS7343_WAITING_START; // Start the measurement please
    AMS_OSRAM_AS7343_checkReadingProgress(ams);               // Call the check function to start it
  return true;
}

/**
 * @brief runs the process of getting readings from all channels without using
 * delays.  Should be called regularly (ie. in loop()) Need to call
 * startReading() to initialise the process Need to call getAllChannels() to
 * transfer the data into an external buffer
 *
 * @return true: reading is complete false: reading is incomplete (or failed)
 */
bool AMS_OSRAM_AS7343_checkReadingProgress(struct AMS_OSRAM_AS7343 *ams) {
  if (ams->_readingState == AS7343_WAITING_START) {
      AMS_OSRAM_AS7343_setSMUXLowChannels(ams, true);        // Configure SMUX to read low channels
      AMS_OSRAM_AS7343_enableSpectralMeasurement(ams, true); // Start integration
    ams->_readingState = AS7343_WAITING_LOW;
    return false;
  }

  if (!AMS_OSRAM_AS7343_getIsDataReady(ams) || ams->_readingState == AS7343_WAITING_DONE)
    return false;

  if (ams->_readingState ==
      AS7343_WAITING_LOW) // Check of getIsDataRead() is already done
  {
    struct Adafruit_BusIO_Register channel_data_reg;
    Adafruit_BusIO_Register_Adafruit_BusIO_Register(&channel_data_reg, AS7343_CH0_DATA_L, 2, LSBFIRST, 1);

    // bool low_success = channel_data_reg.read((uint8_t *)_channel_readings,
    // 12);
    Adafruit_BusIO_Register_read_1(&channel_data_reg, (uint8_t *)ams->_channel_readings, 12);

    AMS_OSRAM_AS7343_setSMUXLowChannels(ams, false);       // Configure SMUX to read high channels
    AMS_OSRAM_AS7343_enableSpectralMeasurement(ams, true); // Start integration
    ams->_readingState = AS7343_WAITING_HIGH;
    return false;
  }

  if (ams->_readingState ==
      AS7343_WAITING_HIGH) // Check of getIsDataRead() is already done
  {
    ams->_readingState = AS7343_WAITING_DONE;
    struct Adafruit_BusIO_Register channel_data_reg;
    Adafruit_BusIO_Register_Adafruit_BusIO_Register(&channel_data_reg, AS7343_CH0_DATA_L, 2, LSBFIRST, 1);
    // return low_success &&			//low_success is lost since it
    // was last call
    Adafruit_BusIO_Register_read_1(&channel_data_reg, (uint8_t *)&ams->_channel_readings[6], 12);
    return true;
  }

  return false;
}

/**
 * @brief transfer all the values from the private result buffer into one
 * nominated
 *
 * @param readings_buffer Pointer to a buffer of length 12 (THERE IS NO ERROR
 * CHECKING, YE BE WARNED!)
 *
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_getAllChannels(struct AMS_OSRAM_AS7343 *ams, uint16_t *readings_buffer) {
  for (int i = 0; i < 12; i++)
    readings_buffer[i] = ams->_channel_readings[i];
  return true;
}

/**
 * @brief Delay while waiting for data, with option to time out and recover
 *
 * @param waitTime the maximum amount of time to wait
 * @return none
 */
void AMS_OSRAM_AS7343_delayForData(struct AMS_OSRAM_AS7343 *ams, int waitTime) {
  if (waitTime == 0) // Wait forever
  {
    while (!AMS_OSRAM_AS7343_getIsDataReady(ams)) {
    	R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
    }
    return;
  }
  if (waitTime > 0) // Wait for that many milliseconds
  {
    uint32_t elapsedMillis = 0;
    while (!AMS_OSRAM_AS7343_getIsDataReady(ams) && elapsedMillis < (uint32_t)waitTime) {
    	R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
      elapsedMillis++;
    }
    return;
  }
  if (waitTime < 0) {
    // For future use?
    return;
  }
}

/**
 * @brief Take readings for F1-8, Clear and NIR and store them in a buffer
 *
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_readAllChannels_1(struct AMS_OSRAM_AS7343 *ams) {
  return AMS_OSRAM_AS7343_readAllChannels_2(ams, ams->_channel_readings);
}

void AMS_OSRAM_AS7343_setSMUXLowChannels(struct AMS_OSRAM_AS7343 *ams, bool f1_f4) {
    AMS_OSRAM_AS7343_enableSpectralMeasurement(ams, false);
    AMS_OSRAM_AS7343_setSMUXCommand(ams, AS7343_SMUX_CMD_WRITE);
  if (f1_f4) {
      AMS_OSRAM_AS7343_setup_F1F4_Clear_NIR(ams);
  } else {
      AMS_OSRAM_AS7343_setup_F5F8_Clear_NIR(ams);
  }
  AMS_OSRAM_AS7343_enableSMUX(ams);
}

/**
 * @brief Sets the power state of the sensor
 *
 * @param enable_power true: on false: off
 */
void AMS_OSRAM_AS7343_powerEnable(struct AMS_OSRAM_AS7343 *ams, bool enable_power) {
  (void)ams;
  struct Adafruit_BusIO_Register enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&enable_reg, AS7343_ENABLE, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits pon_en;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&pon_en, &enable_reg, 1, 0);
  Adafruit_BusIO_RegisterBits_write(&pon_en, enable_power);
}

/**
 * @brief Disable Spectral reading, flicker detection, and power
 *
 * */
void AMS_OSRAM_AS7343_disableAll(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&enable_reg, AS7343_ENABLE, 1, LSBFIRST, 1);
  Adafruit_BusIO_Register_write_2(&enable_reg, 0, 0);
}

/**
 * @brief Enables measurement of spectral data
 *
 * @param enable_measurement true: enabled false: disabled
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_enableSpectralMeasurement(struct AMS_OSRAM_AS7343 *ams, bool enable_measurement) {
  (void)ams;
  struct Adafruit_BusIO_Register enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&enable_reg, AS7343_ENABLE, 1, LSBFIRST, 1);

  struct Adafruit_BusIO_RegisterBits spec_enable_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&spec_enable_bit, &enable_reg, 1, 1);
  return Adafruit_BusIO_RegisterBits_write(&spec_enable_bit, enable_measurement);
}

bool AMS_OSRAM_AS7343_enableSMUX(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&enable_reg, AS7343_ENABLE, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits smux_enable_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&smux_enable_bit, &enable_reg, 1, 4);
  bool success = Adafruit_BusIO_RegisterBits_write(&smux_enable_bit, true);

  int timeOut = 1000; // Arbitrary value, but if it takes 1000 milliseconds then
                      // something is wrong
  int count = 0;
  while (Adafruit_BusIO_RegisterBits_read(&smux_enable_bit) && count < timeOut) {
	  R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
    count++;
  }
  if (count >= timeOut)
    return false;
  else
    return success;
}

bool AMS_OSRAM_AS7343_enableFlickerDetection(struct AMS_OSRAM_AS7343 *ams, bool enable_fd) {
  (void)ams;
  struct Adafruit_BusIO_Register enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&enable_reg, AS7343_ENABLE, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits fd_enable_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&fd_enable_bit, &enable_reg, 1, 6);
  return Adafruit_BusIO_RegisterBits_write(&fd_enable_bit, enable_fd);
}

/**
 * @brief Get the GPIO pin direction setting
 *
 * @return `AS7343_OUTPUT` or `AS7343_INPUT`
 */
AS7343_gpio_dir_t AMS_OSRAM_AS7343_getGPIODirection(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_input_enable;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_input_enable, &gpio2_reg, 1, 2);

  return (AS7343_gpio_dir_t)Adafruit_BusIO_RegisterBits_read(&gpio_input_enable);
}

/**
 * @brief Set the GPIO pin to be used as an input or output
 *
 * @param gpio_direction The IO direction to set
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setGPIODirection(struct AMS_OSRAM_AS7343 *ams, AS7343_gpio_dir_t gpio_direction) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_input_enable;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_input_enable, &gpio2_reg, 1, 2);

  return Adafruit_BusIO_RegisterBits_write(&gpio_input_enable, gpio_direction);
}

/**
 * @brief Get the output inversion setting for the GPIO pin
 *
 * @return true: GPIO output inverted false: GPIO output normal
 */
bool AMS_OSRAM_AS7343_getGPIOInverted(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_output_inverted_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_output_inverted_bit, &gpio2_reg, 1, 3);

  return Adafruit_BusIO_RegisterBits_read(&gpio_output_inverted_bit);
}

/**
 * @brief Invert the logic of then GPIO pin when used as an output
 *
 * @param gpio_inverted **When true** setting the gpio value to **true will
 * connect** the GPIO pin to ground. When set to **false**, setting the GPIO pin
 * value to **true will disconnect** the GPIO pin from ground
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setGPIOInverted(struct AMS_OSRAM_AS7343 *ams, bool gpio_inverted) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_output_inverted_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_output_inverted_bit, &gpio2_reg, 1, 3);

  return Adafruit_BusIO_RegisterBits_write(&gpio_output_inverted_bit, gpio_inverted);
}

/**
 * @brief Read the digital level of the GPIO pin, high or low
 *
 * @return true: GPIO pin level is high false: GPIO pin level is low
 */
bool AMS_OSRAM_AS7343_getGPIOValue(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_input_value_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_input_value_bit, &gpio2_reg, 1, 0);

  return Adafruit_BusIO_RegisterBits_read(&gpio_input_value_bit);
}

/**
 * @brief Set the digital level of the GPIO pin, high or low
 *
 * @param gpio_high The GPIO level to set. Set to true to disconnect the pin
 * from ground. Set to false to connect the gpio pin to ground. This can be used
 * to connect the cathode of an LED to ground to turn it on.
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setGPIOValue(struct AMS_OSRAM_AS7343 *ams, bool gpio_high) {
  (void)ams;
  struct Adafruit_BusIO_Register gpio2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&gpio2_reg, AS7343_GPIO2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits gpio_output_value_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&gpio_output_value_bit, &gpio2_reg, 1, 1);

  return Adafruit_BusIO_RegisterBits_write(&gpio_output_value_bit, gpio_high);
}

bool AMS_OSRAM_AS7343_setSMUXCommand(struct AMS_OSRAM_AS7343 *ams, AS7343_smux_cmd_t command) {
  (void)ams;
  struct Adafruit_BusIO_Register cfg6_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg6_reg, AS7343_CFG6, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits smux_command_bits;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&smux_command_bits, &cfg6_reg, 2, 3);

  return Adafruit_BusIO_RegisterBits_write(&smux_command_bits, command);
}

/**
 * @brief Enable control of an attached LED on the LDR pin
 *
 * @param enable_led true: LED enabled false: LED disabled
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_enableLED(struct AMS_OSRAM_AS7343 *ams, bool enable_led) {
  struct Adafruit_BusIO_Register config_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&config_reg, AS7343_CONFIG, 1, LSBFIRST, 1);
  // Enables control of the LED via the LDR pin
  // 1=control enabled 0 = control disabled
  struct Adafruit_BusIO_RegisterBits led_sel_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&led_sel_bit, &config_reg, 1, 3);

  struct Adafruit_BusIO_Register led_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&led_reg, AS7343_LED, 1, LSBFIRST, 1);
  // turns the LED on or off
  struct Adafruit_BusIO_RegisterBits led_act_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&led_act_bit, &led_reg, 1, 7);

  AMS_OSRAM_AS7343_setBank(ams, true); // Access registers 0x20 to 0x7F
  bool result = Adafruit_BusIO_RegisterBits_write(&led_sel_bit, enable_led) && Adafruit_BusIO_RegisterBits_write(&led_act_bit, enable_led);
  AMS_OSRAM_AS7343_setBank(ams, false); // Access registers 0x80 and above (default)
  return result;
}

/**
 * @brief Set the current limit for the LED
 *
 * @param led_current_ma the value to set in milliamps. With a minimum of 4. Any
 * amount under 4 will be rounded up to 4
 *
 * Range is 4mA to 258mA
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setLEDCurrent(struct AMS_OSRAM_AS7343 *ams, uint16_t led_current_ma) {
  // check within permissible range
  if (led_current_ma > 258) {
    return false;
  }
  if (led_current_ma < 4) {
    led_current_ma = 4;
  }
  AMS_OSRAM_AS7343_setBank(ams, true); // //Access registers 0x20 to 0x7F

  struct Adafruit_BusIO_Register led_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&led_reg, AS7343_LED, 1, LSBFIRST, 1);

  // true = led on , false = off
  struct Adafruit_BusIO_RegisterBits led_current_bits;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&led_current_bits, &led_reg, 7, 0);

  bool result = Adafruit_BusIO_RegisterBits_write(&led_current_bits, (uint8_t)((led_current_ma - 4) / 2));
  AMS_OSRAM_AS7343_setBank(ams, false); // Access registers 0x80 and above (default)
  return result;
}

/**
 * @brief Get the current limit for the LED
 *
 * Range is 4mA to 258mA
 * @return current limit in mA
 */
uint16_t AMS_OSRAM_AS7343_getLEDCurrent(struct AMS_OSRAM_AS7343 *ams) {
  uint16_t led_current_ma;
  uint32_t led_raw;

  AMS_OSRAM_AS7343_setBank(ams, true); // Access registers 0x20 to 0x7F

  struct Adafruit_BusIO_Register led_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&led_reg, AS7343_LED, 1, LSBFIRST, 1);

  struct Adafruit_BusIO_RegisterBits led_current_bits;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&led_current_bits, &led_reg, 7, 0);

  led_raw = Adafruit_BusIO_RegisterBits_read(&led_current_bits);

  led_current_ma = (uint16_t)(led_raw * 2) + 4;
  AMS_OSRAM_AS7343_setBank(ams, false); // Access registers 0x80 and above (default)
  return led_current_ma;
}

/**
 * @brief Sets the active register bank
 *
 * The AS7343 uses banks to organize the register making it nescessary to set
 * the correct bank to access a register.
 *

 * @param low **true**:
 * **false**: Set the current bank to allow access to registers with addresses
 of `0x80` and above
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setBank(struct AMS_OSRAM_AS7343 *ams, bool low) {
  (void)ams;
  struct Adafruit_BusIO_Register cfg0_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg0_reg, AS7343_CFG0, 1, LSBFIRST, 1);
  // register map says shift 3, 0xA9 description says shift 4 with 3 being
  // reserved
  struct Adafruit_BusIO_RegisterBits bank_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&bank_bit, &cfg0_reg, 1, 4);

  return Adafruit_BusIO_RegisterBits_write(&bank_bit, low);
}

/**
 * @brief Sets the threshold below which spectral measurements will trigger
 * interrupts when the APERS count is reached
 *
 * @param low_threshold the new threshold
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setLowThreshold(struct AMS_OSRAM_AS7343 *ams, uint16_t low_threshold) {
  (void)ams;
  struct Adafruit_BusIO_Register sp_low_threshold_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&sp_low_threshold_reg, AS7343_SP_LOW_TH_L, 2, LSBFIRST, 1);
  return Adafruit_BusIO_Register_write_2(&sp_low_threshold_reg, low_threshold, 0);
}

/**
 * @brief Returns the current low thighreshold for spectral measurements
 *
 * @return int16_t The current low threshold
 */
uint16_t AMS_OSRAM_AS7343_getLowThreshold(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register sp_low_threshold_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&sp_low_threshold_reg, AS7343_SP_LOW_TH_L, 2, LSBFIRST, 1);
  return (uint16_t)Adafruit_BusIO_Register_read_4(&sp_low_threshold_reg);
}

/**
 * @brief Sets the threshold above which spectral measurements will trigger
 * interrupts when the APERS count is reached
 *
 * @param high_threshold
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setHighThreshold(struct AMS_OSRAM_AS7343 *ams, uint16_t high_threshold) {
  (void)ams;
  struct Adafruit_BusIO_Register sp_high_threshold_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&sp_high_threshold_reg, AS7343_SP_HIGH_TH_L, 2, LSBFIRST, 1);
  return Adafruit_BusIO_Register_write_2(&sp_high_threshold_reg, high_threshold, 0);
}

/**
 * @brief Returns the current high thighreshold for spectral measurements
 *
 * @return int16_t The current high threshold
 */
uint16_t AMS_OSRAM_AS7343_getHighThreshold(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register sp_high_threshold_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&sp_high_threshold_reg, AS7343_SP_HIGH_TH_L, 2, LSBFIRST, 1);
  return (uint16_t)Adafruit_BusIO_Register_read_4(&sp_high_threshold_reg);
}

/**
 * @brief Enable Interrupts based on spectral measurements
 *
 * @param enable_int true: enable false: disable
 * @return true: success false: falure
 */
bool AMS_OSRAM_AS7343_enableSpectralInterrupt(struct AMS_OSRAM_AS7343 *ams, bool enable_int) {
  (void)ams;
  struct Adafruit_BusIO_Register int_enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&int_enable_reg, AS7343_INTENAB, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits sp_int_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&sp_int_bit, &int_enable_reg, 1, 3);
  return Adafruit_BusIO_RegisterBits_write(&sp_int_bit, enable_int);
}

/**
 * @brief Enabled system interrupts
 *
 * @param enable_int Set to true to enable system interrupts
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_enableSystemInterrupt(struct AMS_OSRAM_AS7343 *ams, bool enable_int) {
  (void)ams;
  struct Adafruit_BusIO_Register int_enable_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&int_enable_reg, AS7343_INTENAB, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits sien_int_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&sien_int_bit, &int_enable_reg, 1, 0);
  return Adafruit_BusIO_RegisterBits_write(&sien_int_bit, enable_int);
}

// Spectral Interrupt Persistence.
// Defines a filter for the number of consecutive
// occurrences that spectral data must remain outside
// the threshold range between SP_TH_L and
// SP_TH_H before an interrupt is generated. The
// spectral data channel used for the persistence filter
// is set by SP_TH_CHANNEL. Any sample that is
// inside the threshold range resets the counter to 0.

/**
 * @brief Sets the number of times an interrupt threshold must be exceeded
 * before an interrupt is triggered
 *
 * @param cycle_count The number of cycles to trigger an interrupt
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setAPERS(struct AMS_OSRAM_AS7343 *ams, AS7343_int_cycle_count_t cycle_count) {
  (void)ams;
  struct Adafruit_BusIO_Register pers_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&pers_reg, AS7343_PERS, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits apers_bits;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&apers_bits, &pers_reg, 4, 0);
  return Adafruit_BusIO_RegisterBits_write(&apers_bits, cycle_count);
}

/**
 * @brief Set the ADC channel to use for spectral thresholds including
 * interrupts, automatic gain control, and persistance settings
 *
 * @param channel The channel to use for spectral thresholds. Must be a
 * AS7343_adc_channel_t **except for** `AS7343_ADC_CHANNEL_5`
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setSpectralThresholdChannel(struct AMS_OSRAM_AS7343 *ams,
    AS7343_adc_channel_t channel) {
  (void)ams;
  if (channel == AS7343_ADC_CHANNEL_5) {
    return false;
  }
  struct Adafruit_BusIO_Register cfg_12_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg_12_reg, AS7343_CFG12, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits spectral_threshold_ch_bits;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&spectral_threshold_ch_bits, &cfg_12_reg, 3, 0);
  return Adafruit_BusIO_RegisterBits_write(&spectral_threshold_ch_bits, channel);
}

/**
 * @brief Returns the current value of the Interupt status register
 *
 * @return uint8_t
 */
uint8_t AMS_OSRAM_AS7343_getInterruptStatus(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register int_status_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&int_status_reg, AS7343_STATUS, 1, LSBFIRST, 1);
  return (uint8_t)Adafruit_BusIO_Register_read_4(&int_status_reg);
}

/**
 * @brief Returns the status of the spectral measurement threshold interrupts
 *
 * @return true: interrupt triggered false: interrupt not triggered
 */
bool AMS_OSRAM_AS7343_spectralInterruptTriggered(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register int_status_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&int_status_reg, AS7343_STATUS, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits aint_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&aint_bit, &int_status_reg, 1, 3);

  return Adafruit_BusIO_RegisterBits_read(&aint_bit);
}

/**
 * @brief Clear the interrupt status register
 *
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_clearInterruptStatus(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register int_status_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&int_status_reg, AS7343_STATUS, 1, LSBFIRST, 1);

  return Adafruit_BusIO_Register_write_2(&int_status_reg, 0xFF, 0);
}

/**
 * @brief The current state of the spectral measurement interrupt status
 * register
 *
 * @return uint8_t The current status register
 */
uint8_t AMS_OSRAM_AS7343_spectralInterruptSource(struct AMS_OSRAM_AS7343 *ams) {
  struct Adafruit_BusIO_Register status3_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status3_reg, AS7343_STATUS3, 1, LSBFIRST, 1);

  uint8_t spectral_int_source = (uint8_t)Adafruit_BusIO_Register_read_4(&status3_reg);
  ams->last_spectral_int_source = spectral_int_source;
  return spectral_int_source;
}

/**
 * @brief The status of the low threshold interrupt
 *
 * @return true: low interrupt triggered false: interrupt not triggered
 */
bool AMS_OSRAM_AS7343_spectralLowTriggered(struct AMS_OSRAM_AS7343 *ams) {
  return (ams->last_spectral_int_source & AS7343_SPECTRAL_INT_LOW_MSK) > 0;
}

/**
 * @brief The status of the high threshold interrupt
 *
 * @return true: high interrupt triggered false: interrupt not triggered
 */
bool AMS_OSRAM_AS7343_spectralHighTriggered(struct AMS_OSRAM_AS7343 *ams) {
  return (ams->last_spectral_int_source & AS7343_SPECTRAL_INT_HIGH_MSK) > 0;
}

/**
 * @brief
 *
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_getIsDataReady(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register status2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status2_reg, AS7343_STATUS2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits avalid_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&avalid_bit, &status2_reg, 1, 6);

	//return 0;
  return Adafruit_BusIO_RegisterBits_read(&avalid_bit);
}

/**
 * @brief Configure SMUX for sensors F1-4, Clear and NIR
 *
 */
void AMS_OSRAM_AS7343_setup_F1F4_Clear_NIR(struct AMS_OSRAM_AS7343 *ams) {
  // SMUX Config for F1,F2,F3,F4,NIR,Clear
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)0x00, (uint8_t)0x30); // F3 left set to ADC2
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x01), (uint8_t)(0x01)); // F1 left set to ADC0
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x02), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x03), (uint8_t)(0x00)); // F8 left disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x04), (uint8_t)(0x00)); // F6 left disabled
    AMS_OSRAM_AS7343_writeRegister(ams,
      (uint8_t)(0x05),
      (uint8_t)(0x42)); // F4 left connected to ADC3/f2 left connected to ADC1
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x06), (uint8_t)(0x00)); // F5 left disbled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x07), (uint8_t)(0x00)); // F7 left disbled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x08), (uint8_t)(0x50)); // CLEAR connected to ADC4
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x09), (uint8_t)(0x00)); // F5 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0A), (uint8_t)(0x00)); // F7 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0B), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0C), (uint8_t)(0x20)); // F2 right connected to ADC1
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0D), (uint8_t)(0x04)); // F4 right connected to ADC3
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0E), (uint8_t)(0x00)); // F6/F8 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0F), (uint8_t)(0x30)); // F3 right connected to AD2
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x10), (uint8_t)(0x01)); // F1 right connected to AD0
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x11), (uint8_t)(0x50)); // CLEAR right connected to AD4
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x12), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x13), (uint8_t)(0x06)); // NIR connected to ADC5
}

/**
 * @brief Configure SMUX for sensors F5-8, Clear and NIR
 *
 */
void AMS_OSRAM_AS7343_setup_F5F8_Clear_NIR(struct AMS_OSRAM_AS7343 *ams) {
  // SMUX Config for F5,F6,F7,F8,NIR,Clear
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x00), (uint8_t)(0x00)); // F3 left disable
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x01), (uint8_t)(0x00)); // F1 left disable
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x02), (uint8_t)(0x00)); // reserved/disable
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x03), (uint8_t)(0x40)); // F8 left connected to ADC3
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x04), (uint8_t)(0x02)); // F6 left connected to ADC1
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x05), (uint8_t)(0x00)); // F4/ F2 disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x06), (uint8_t)(0x10)); // F5 left connected to ADC0
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x07), (uint8_t)(0x03)); // F7 left connected to ADC2
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x08), (uint8_t)(0x50)); // CLEAR Connected to ADC4
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x09), (uint8_t)(0x10)); // F5 right connected to ADC0
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0A), (uint8_t)(0x03)); // F7 right connected to ADC2
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0B), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0C), (uint8_t)(0x00)); // F2 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0D), (uint8_t)(0x00)); // F4 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams,
      (uint8_t)(0x0E),
      (uint8_t)(0x24)); // F8 right connected to ADC2/ F6 right connected to ADC1
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0F), (uint8_t)(0x00)); // F3 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x10), (uint8_t)(0x00)); // F1 right disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x11), (uint8_t)(0x50)); // CLEAR right connected to AD4
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x12), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x13), (uint8_t)(0x06)); // NIR connected to ADC5
}

/**
 * @brief Configure SMUX for flicker detection
 *
 */
void AMS_OSRAM_AS7343_FDConfig(struct AMS_OSRAM_AS7343 *ams) {
  // SMUX Config for Flicker- register (0x13)left set to ADC6 for flicker
  // detection
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x00), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x01), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x02), (uint8_t)(0x00)); // reserved/disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x03), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x04), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x05), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x06), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x07), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x08), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x09), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0A), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0B), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0C), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0D), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0E), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x0F), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x10), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x11), (uint8_t)(0x00)); // disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x12), (uint8_t)(0x00)); // Reserved or disabled
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(0x13),
                (uint8_t)(0x60)); // Flicker connected to ADC5 to left of 0x13
}

// TODO; check for valid values
/**
 * @brief Sets the integration time step count
 *
 * Total integration time will be `(ATIME + 1) * (ASTEP + 1) * 2.78µS`
 *
 * @param atime_value The integration time step count
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setATIME(struct AMS_OSRAM_AS7343 *ams, uint8_t atime_value) {
  (void)ams;
  struct Adafruit_BusIO_Register atime_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&atime_reg, AS7343_ATIME, 1, LSBFIRST, 1);
  return Adafruit_BusIO_Register_write_2(&atime_reg, atime_value, 0);
}

/**
 * @brief Returns the integration time step count
 *
 * Total integration time will be `(ATIME + 1) * (ASTEP + 1) * 2.78µS`
 *
 * @return uint8_t The current integration time step count
 */
uint8_t AMS_OSRAM_AS7343_getATIME(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register atime_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&atime_reg, AS7343_ATIME, 1, LSBFIRST, 1);
  return (uint8_t)Adafruit_BusIO_Register_read_4(&atime_reg);
}

/**
 * @brief Sets the integration time step size
 *
 * @param astep_value Integration time step size in 2.78 microsecon increments
 * Step size is `(astep_value+1) * 2.78 uS`
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setASTEP(struct AMS_OSRAM_AS7343 *ams, uint16_t astep_value) {
  (void)ams;
  struct Adafruit_BusIO_Register astep_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&astep_reg, AS7343_ASTEP_L, 2, LSBFIRST, 1);
  return Adafruit_BusIO_Register_write_2(&astep_reg, astep_value, 0);
}

/**
 * @brief Returns the integration time step size
 *
 * Step size is `(astep_value+1) * 2.78 uS`
 *
 * @return uint16_t The current integration time step size
 */
uint16_t AMS_OSRAM_AS7343_getASTEP(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register astep_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&astep_reg, AS7343_ASTEP_L, 2, LSBFIRST, 1);
  return (uint16_t)Adafruit_BusIO_Register_read_4(&astep_reg);
}

/**
 * @brief Sets the ADC gain multiplier
 *
 * @param gain_value The gain amount. must be an `AS7343_gain_t`
 * @return true: success false: failure
 */
bool AMS_OSRAM_AS7343_setGain(struct AMS_OSRAM_AS7343 *ams, AS7343_gain_t gain_value) {
  (void)ams;
  struct Adafruit_BusIO_Register cfg1_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg1_reg, AS7343_CFG1, 1, LSBFIRST, 1);
  return Adafruit_BusIO_Register_write_2(&cfg1_reg, gain_value, 0);
  // AGAIN bitfield is only[0:4] but the rest is empty
}

/**
 * @brief Returns the ADC gain multiplier
 *
 * @return AS7343_gain_t The current ADC gain multiplier
 */
AS7343_gain_t AMS_OSRAM_AS7343_getGain(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register cfg1_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&cfg1_reg, AS7343_CFG1, 1, LSBFIRST, 1);
  return (AS7343_gain_t)Adafruit_BusIO_Register_read_4(&cfg1_reg);
}

/**
 * @brief Returns the integration time
 *
 * The integration time is `(ATIME + 1) * (ASTEP + 1) * 2.78µS`
 *
 * @return long The current integration time in ms
 */
long AMS_OSRAM_AS7343_getTINT(struct AMS_OSRAM_AS7343 *ams) {
  uint16_t astep = AMS_OSRAM_AS7343_getASTEP(ams);
  uint8_t atime = AMS_OSRAM_AS7343_getATIME(ams);

  return (long)((atime + 1) * (astep + 1) * 2.78 / 1000);
}

/**
 * @brief Converts raw ADC values to basic counts
 *
 * The basic counts are `RAW/(GAIN * TINT)`
 *
 * @param raw The raw ADC values to convert
 *
 * @return float The basic counts
 */
double AMS_OSRAM_AS7343_toBasicCounts(struct AMS_OSRAM_AS7343 *ams, uint16_t raw) {
  float gain_val = 0;
  AS7343_gain_t gain = AMS_OSRAM_AS7343_getGain(ams);
  switch (gain) {
  case AS7343_GAIN_0_5X:
    gain_val = 0.5;
    break;
  case AS7343_GAIN_1X:
    gain_val = 1;
    break;
  case AS7343_GAIN_2X:
    gain_val = 2;
    break;
  case AS7343_GAIN_4X:
    gain_val = 4;
    break;
  case AS7343_GAIN_8X:
    gain_val = 8;
    break;
  case AS7343_GAIN_16X:
    gain_val = 16;
    break;
  case AS7343_GAIN_32X:
    gain_val = 32;
    break;
  case AS7343_GAIN_64X:
    gain_val = 64;
    break;
  case AS7343_GAIN_128X:
    gain_val = 128;
    break;
  case AS7343_GAIN_256X:
    gain_val = 256;
    break;
  case AS7343_GAIN_512X:
    gain_val = 512;
    break;
  case AS7343_GAIN_1024X:
      gain_val = 1024;
      break;
  case AS7343_GAIN_2048X:
        gain_val = 2048;
        break;
  }
  return raw / (gain_val * (AMS_OSRAM_AS7343_getATIME(ams) + 1) * (AMS_OSRAM_AS7343_getASTEP(ams) + 1) * 2.78 / 1000);
}

/**
 * @brief Detect a flickering light
 * @return The frequency of a detected flicker or 1 if a flicker of
 * unknown frequency is detected
 */
uint16_t AMS_OSRAM_AS7343_detectFlickerHz(struct AMS_OSRAM_AS7343 *ams) {
  // bool isEnabled = true;
  // bool isFdmeasReady = false;

  // disable everything; Flicker detect, smux, wait, spectral, power
    AMS_OSRAM_AS7343_disableAll(ams);
  // re-enable power
    AMS_OSRAM_AS7343_powerEnable(ams, true);

  // Write SMUX configuration from RAM to set SMUX chain registers (Write 0x10
  // to CFG6)
    AMS_OSRAM_AS7343_setSMUXCommand(ams, AS7343_SMUX_CMD_WRITE);

  // Write new configuration to all the 20 registers for detecting Flicker
    AMS_OSRAM_AS7343_FDConfig(ams);

  // Start SMUX command
    AMS_OSRAM_AS7343_enableSMUX(ams);

  // Enable SP_EN bit
    AMS_OSRAM_AS7343_enableSpectralMeasurement(ams, true);

  // Enable flicker detection bit
    AMS_OSRAM_AS7343_writeRegister(ams, (uint8_t)(AS7343_ENABLE), (uint8_t)(0x41));
  R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS); // SF 2020-08-12 Does this really need to be so long?
  int8_t flicker_status = AMS_OSRAM_AS7343_getFlickerDetectStatus(ams);
  AMS_OSRAM_AS7343_enableFlickerDetection(ams, false);
  switch (flicker_status) {
  case 44:
    return 1;
  case 45:
    return 100;
  case 46:
    return 120;
  default:
    return 0;
  }
}

/**
 * @brief Write a uint8_t to the given register
 *
 * @param addr Register address
 * @param val The value to set the register to
 */
void AMS_OSRAM_AS7343_writeRegister(struct AMS_OSRAM_AS7343 *ams, uint8_t addr, uint8_t val) {
  (void)ams;
  struct Adafruit_BusIO_Register reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&reg, addr, 1, LSBFIRST, 1);
  Adafruit_BusIO_Register_write_2(&reg, val, 0);
}

bool AMS_OSRAM_AS7343_digitalSaturation(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register status2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status2_reg, AS7343_STATUS2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits asat_digital_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&asat_digital_bit, &status2_reg, 1, 4);

  return Adafruit_BusIO_RegisterBits_read(&asat_digital_bit);
}

bool AMS_OSRAM_AS7343_analogSaturation(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register status2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status2_reg, AS7343_STATUS2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits asat_analog_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&asat_analog_bit, &status2_reg, 1, 3);

  return Adafruit_BusIO_RegisterBits_read(&asat_analog_bit);
}


bool AMS_OSRAM_AS7343_clearDigitalSaturationStatus(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register status2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status2_reg, AS7343_STATUS2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits asat_digital_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&asat_digital_bit, &status2_reg, 1, 4);
  return Adafruit_BusIO_RegisterBits_write(&asat_digital_bit, 0);
}

bool AMS_OSRAM_AS7343_clearAnalogSaturationStatus(struct AMS_OSRAM_AS7343 *ams) {
  (void)ams;
  struct Adafruit_BusIO_Register status2_reg;
  Adafruit_BusIO_Register_Adafruit_BusIO_Register(&status2_reg, AS7343_STATUS2, 1, LSBFIRST, 1);
  struct Adafruit_BusIO_RegisterBits asat_analog_bit;
  Adafruit_BusIO_RegisterBits_Adafruit_BusIO_RegisterBits(&asat_analog_bit, &status2_reg, 1, 3);
  return Adafruit_BusIO_RegisterBits_write(&asat_analog_bit, 0);
}

#endif
