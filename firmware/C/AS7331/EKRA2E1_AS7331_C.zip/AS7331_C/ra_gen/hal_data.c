/* generated HAL source file - do not edit */
#include "hal_data.h"
#include "r_sci_i2c_cfg.h"
sci_i2c_instance_ctrl_t g_i2c0_ctrl;
const sci_i2c_extended_cfg_t g_i2c0_cfg_extend =
        {
          /* Actual calculated bitrate: 375000. Actual SDA delay: 333.3333333333333 ns. */.clock_settings.clk_divisor_value =
                  0,
          .clock_settings.brr_value = 1,
          .clock_settings.mddr_value = 255,
          .clock_settings.bitrate_modulation = false,
          .clock_settings.cycles_value = 8,
          .clock_settings.snfr_value = (1), };

const i2c_master_cfg_t g_i2c0_cfg =
{ .channel = 2, .rate = I2C_MASTER_RATE_FAST, .slave = 0x74, .addr_mode = I2C_MASTER_ADDR_MODE_7BIT,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_transfer_tx = NULL,
#else
    .p_transfer_tx       = &RA_NOT_DEFINED,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_transfer_rx = NULL,
#else
    .p_transfer_rx       = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .p_callback = i2c_master_callback,
  .p_context = NULL,
#if defined(VECTOR_NUMBER_SCI2_RXI) && SCI_I2C_CFG_DTC_ENABLE
    .rxi_irq             = VECTOR_NUMBER_SCI2_RXI,
#else
  .rxi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SCI2_TXI)
    .txi_irq             = VECTOR_NUMBER_SCI2_TXI,
#else
  .txi_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_SCI2_TEI)
    .tei_irq             = VECTOR_NUMBER_SCI2_TEI,
#else
  .tei_irq = FSP_INVALID_VECTOR,
#endif
  .ipl = (2), /* (BSP_IRQ_DISABLED) is unused */
  .p_extend = &g_i2c0_cfg_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c0 =
{ .p_ctrl = &g_i2c0_ctrl, .p_cfg = &g_i2c0_cfg, .p_api = &g_i2c_master_on_sci };
void g_hal_init(void)
{
    g_common_init ();
}
